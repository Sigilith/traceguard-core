"""ThreeLineage shared utilities."""
