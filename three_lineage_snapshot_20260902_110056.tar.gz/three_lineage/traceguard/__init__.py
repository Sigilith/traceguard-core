"""ThreeLineage TraceGuard integration boundary."""
